import asyncio
import random
import re
import time
import traceback
from collections.abc import AsyncGenerator

from astrbot.core import file_token_service, html_renderer, logger
from astrbot.core.message.components import At, Image, Json, Node, Plain, Record, Reply
from astrbot.core.message.message_event_result import ResultContentType
from astrbot.core.pipeline.content_safety_check.stage import ContentSafetyCheckStage
from astrbot.core.platform.astr_message_event import AstrMessageEvent
from astrbot.core.platform.message_type import MessageType
from astrbot.core.star.session_llm_manager import SessionServiceManager
from astrbot.core.star.star import star_map
from astrbot.core.star.star_handler import EventType, star_handlers_registry

from ..chat_layout import is_valid_audio_file, make_tts_text
from ..context import PipelineContext
from ..stage import Stage, register_stage, registered_stages


@register_stage
class ResultDecorateStage(Stage):
    async def initialize(self, ctx: PipelineContext) -> None:
        self.ctx = ctx
        self.reply_prefix = ctx.astrbot_config["platform_settings"]["reply_prefix"]
        self.reply_with_mention = ctx.astrbot_config["platform_settings"][
            "reply_with_mention"
        ]
        self.reply_with_quote = ctx.astrbot_config["platform_settings"][
            "reply_with_quote"
        ]
        self.t2i_word_threshold = ctx.astrbot_config["t2i_word_threshold"]
        try:
            self.t2i_word_threshold = int(self.t2i_word_threshold)
            self.t2i_word_threshold = max(self.t2i_word_threshold, 50)
        except BaseException:
            self.t2i_word_threshold = 150
        self.t2i_strategy = ctx.astrbot_config["t2i_strategy"]
        self.t2i_use_network = self.t2i_strategy == "remote"
        self.t2i_active_template = ctx.astrbot_config["t2i_active_template"]

        self.forward_threshold = ctx.astrbot_config["platform_settings"][
            "forward_threshold"
        ]

        trigger_probability = ctx.astrbot_config["provider_tts_settings"].get(
            "trigger_probability",
            1,
        )
        try:
            self.tts_trigger_probability = max(
                0.0,
                min(float(trigger_probability), 1.0),
            )
        except (TypeError, ValueError):
            self.tts_trigger_probability = 1.0

        # 分段回复
        self.words_count_threshold = int(
            ctx.astrbot_config["platform_settings"]["segmented_reply"][
                "words_count_threshold"
            ],
        )
        self.enable_segmented_reply = ctx.astrbot_config["platform_settings"][
            "segmented_reply"
        ]["enable"]
        self.only_llm_result = ctx.astrbot_config["platform_settings"][
            "segmented_reply"
        ]["only_llm_result"]
        self.split_mode = ctx.astrbot_config["platform_settings"][
            "segmented_reply"
        ].get("split_mode", "regex")
        self.regex = ctx.astrbot_config["platform_settings"]["segmented_reply"]["regex"]
        self.split_words = ctx.astrbot_config["platform_settings"][
            "segmented_reply"
        ].get("split_words", ["。", "？", "！", "~", "…"])
        if self.split_words:
            escaped_words = sorted(
                [re.escape(word) for word in self.split_words], key=len, reverse=True
            )
            self.split_words_pattern = re.compile(
                f"(.*?({'|'.join(escaped_words)})|.+$)", re.DOTALL
            )
        else:
            self.split_words_pattern = None
        self.content_cleanup_rule = ctx.astrbot_config["platform_settings"][
            "segmented_reply"
        ]["content_cleanup_rule"]
        # 整段语音的兜底时限；TTS 卡住时必须退回文字，不能把整条回复拖死。
        tts_cfg = ctx.astrbot_config.get("provider_tts_settings", {})
        try:
            self.tts_timeout_s = max(3.0, float(tts_cfg.get("timeout", 30)))
        except (TypeError, ValueError):
            self.tts_timeout_s = 30.0
        try:
            # 单次合成的文本上限；超长回复直接发文字，避免供应商截断/报错。
            self.tts_max_chars = max(50, int(tts_cfg.get("max_chars", 600)))
        except (TypeError, ValueError):
            self.tts_max_chars = 600

        # exception
        self.content_safe_check_reply = ctx.astrbot_config["content_safety"][
            "also_use_in_response"
        ]
        self.content_safe_check_stage = None
        if self.content_safe_check_reply:
            for stage_cls in registered_stages:
                if stage_cls.__name__ == "ContentSafetyCheckStage":
                    self.content_safe_check_stage = stage_cls()
                    await self.content_safe_check_stage.initialize(ctx)

        provider_cfg = ctx.astrbot_config.get("provider_settings", {})
        self.show_reasoning = provider_cfg.get("display_reasoning_text", False)

    def _split_text_by_words(self, text: str) -> list[str]:
        """使用分段词列表分段文本"""
        if not self.split_words_pattern:
            return [text]

        segments = self.split_words_pattern.findall(text)
        result = []
        for seg in segments:
            if isinstance(seg, tuple):
                content = seg[0]
                if not isinstance(content, str):
                    continue
                for word in self.split_words:
                    if content.endswith(word):
                        content = content[: -len(word)]
                        break
                if content.strip():
                    result.append(content)
            elif seg and seg.strip():
                result.append(seg)
        return result if result else [text]

    async def process(
        self,
        event: AstrMessageEvent,
    ) -> None | AsyncGenerator[None, None]:
        result = event.get_result()
        if result is None or not result.chain:
            return

        if result.result_content_type == ResultContentType.STREAMING_RESULT:
            return

        is_stream = result.result_content_type == ResultContentType.STREAMING_FINISH

        # 回复时检查内容安全
        if (
            self.content_safe_check_reply
            and self.content_safe_check_stage
            and result.is_llm_result()
            and not is_stream  # 流式输出不检查内容安全
        ):
            text = ""
            for comp in result.chain:
                if isinstance(comp, Plain):
                    text += comp.text

            if isinstance(self.content_safe_check_stage, ContentSafetyCheckStage):
                async for _ in self.content_safe_check_stage.process(
                    event,
                    check_text=text,
                ):
                    yield

        # 发送消息前事件钩子
        handlers = star_handlers_registry.get_handlers_by_event_type(
            EventType.OnDecoratingResultEvent,
            plugins_name=event.plugins_name,
        )
        for handler in handlers:
            try:
                logger.debug(
                    f"hook(on_decorating_result) -> {star_map[handler.handler_module_path].name} - {handler.handler_name}",
                )
                if is_stream:
                    logger.warning(
                        "Plugins that depend on the pre-send event hook may not work "
                        "correctly when streaming output is enabled.",
                    )
                await handler.handler(event)

                if (result := event.get_result()) is None or not result.chain:
                    logger.debug(
                        "hook(on_decorating_result) -> "
                        f"{star_map[handler.handler_module_path].name} - "
                        f"{handler.handler_name} cleared the message result.",
                    )
            except BaseException:
                logger.error(traceback.format_exc())

            if event.is_stopped():
                logger.info(
                    f"{star_map[handler.handler_module_path].name} - "
                    f"{handler.handler_name} stopped event propagation.",
                )
                return

        # 流式输出不执行下面的逻辑
        if is_stream:
            return

        # 需要再获取一次。插件可能直接对 chain 进行了替换。
        result = event.get_result()
        if result is None:
            return

        if len(result.chain) > 0:
            # 回复前缀
            if self.reply_prefix:
                for comp in result.chain:
                    if isinstance(comp, Plain):
                        comp.text = self.reply_prefix + comp.text
                        break

            # 分段前先保存完整语义文本：语音按整段合成，显示才分气泡。
            # 这样表情、标点和句子结构不会因为分泡而反复重置语调。
            full_reply_text = "".join(
                comp.text for comp in result.chain if isinstance(comp, Plain)
            )

            # 分段回复
            if self.enable_segmented_reply and event.get_platform_name() not in [
                "qq_official_webhook",
                "weixin_official_account",
                "dingtalk",
            ]:
                if (
                    self.only_llm_result and result.is_model_result()
                ) or not self.only_llm_result:
                    # 阈值按“整条回复”算，不能因为表情把 Plain 切开就误判成短消息。
                    long_reply = len(full_reply_text) > self.words_count_threshold
                    new_chain = []
                    for comp in result.chain:
                        if isinstance(comp, Plain):
                            if long_reply:
                                # 长回复不分段，整段发出去
                                new_chain.append(comp)
                                continue

                            # 根据 split_mode 选择分段方式
                            if self.split_mode == "words":
                                split_response = self._split_text_by_words(comp.text)
                            else:  # regex 模式
                                try:
                                    split_response = re.findall(
                                        self.regex,
                                        comp.text,
                                        re.DOTALL | re.MULTILINE,
                                    )
                                except re.error:
                                    logger.error(
                                        "Invalid segmented-reply regular expression; "
                                        "using the default segmentation method: "
                                        f"{traceback.format_exc()}",
                                    )
                                    split_response = re.findall(
                                        r".*?[。？！~…]+|.+$",
                                        comp.text,
                                        re.DOTALL | re.MULTILINE,
                                    )

                            if not split_response:
                                new_chain.append(comp)
                                continue
                            for seg in split_response:
                                if self.content_cleanup_rule:
                                    try:
                                        seg = re.sub(self.content_cleanup_rule, "", seg)
                                    except re.error:
                                        logger.error(
                                            "The segmented-reply filter expression "
                                            "failed, so the text could not be filtered: "
                                            f"{traceback.format_exc()}"
                                        )
                                        self.content_cleanup_rule = None
                                seg = seg.strip()
                                if seg:
                                    new_chain.append(Plain(seg))
                        else:
                            # 非 Plain 类型的消息段不分段
                            new_chain.append(comp)
                    result.chain = new_chain

            # TTS
            tts_provider = (
                await self.ctx.plugin_manager.context.get_using_tts_provider_async(
                    event.unified_msg_origin,
                )
            )

            should_tts = (
                bool(self.ctx.astrbot_config["provider_tts_settings"]["enable"])
                and result.is_llm_result()
                and await SessionServiceManager.should_process_tts_request(event)
                and random.random() <= self.tts_trigger_probability
                and tts_provider
            )
            if should_tts and not tts_provider:
                logger.warning(
                    f"Session {event.unified_msg_origin} has no text-to-speech "
                    "provider configured.",
                )

            show_reasoning = self.show_reasoning
            if (enable_reasoning := event.get_extra("enable_reasoning")) is not None:
                show_reasoning = bool(enable_reasoning)

            if (
                not should_tts
                and show_reasoning
                and event.get_extra("_llm_reasoning_content")
            ):
                # inject reasoning content to chain
                reasoning_content = str(event.get_extra("_llm_reasoning_content"))
                if event.get_platform_name() == "lark":
                    result.chain.insert(
                        0,
                        Json(
                            data={
                                "type": "lark_collapsible_panel_reasoning",
                                "title": "💭 Thinking",
                                "expanded": False,
                                "content": reasoning_content,
                            },
                        ),
                    )
                else:
                    result.chain.insert(
                        0, Plain(f"🤔 思考: {reasoning_content}\n\n────\n")
                    )

            if should_tts and tts_provider:
                # 补丁3: 整条回复只合成一次语音。显示气泡照常分，但语音不再
                # 按气泡逐段合成——表情和分泡不会再把一句话的语调切碎。
                if any(isinstance(comp, Record) for comp in result.chain):
                    logger.info("TTS skipped: the result already contains a voice record")
                else:
                    tts_text = make_tts_text(full_reply_text)
                    if not tts_text:
                        logger.info("TTS skipped: reply has no readable text")
                    elif len(tts_text) > self.tts_max_chars:
                        logger.info(
                            "TTS skipped: reply is %d chars, above the %d-char limit",
                            len(tts_text),
                            self.tts_max_chars,
                        )
                    else:
                        try:
                            logger.info(f"TTS request (whole reply): {tts_text[:200]}")
                            audio_path = await asyncio.wait_for(
                                tts_provider.get_audio(tts_text),
                                timeout=self.tts_timeout_s,
                            )
                            logger.info(f"TTS result: {audio_path}")
                            if not is_valid_audio_file(audio_path):
                                raise RuntimeError(
                                    "TTS provider returned an empty or unreadable audio file"
                                )

                            tts_settings = self.ctx.astrbot_config[
                                "provider_tts_settings"
                            ]
                            callback_api_base = self.ctx.astrbot_config[
                                "callback_api_base"
                            ]
                            url = None
                            if tts_settings["use_file_service"] and callback_api_base:
                                token = await file_token_service.register_file(
                                    audio_path,
                                )
                                url = f"{callback_api_base}/api/file/{token}"
                                logger.debug(f"Registered: {url}")

                            record = Record(
                                file=url or audio_path,
                                url=url or audio_path,
                                text=tts_text,
                            )
                            if tts_settings["dual_output"]:
                                # 文字气泡 + 一条完整语音
                                result.chain.append(record)
                            else:
                                # 只发语音，保留图片等非文本段
                                result.chain = [record] + [
                                    comp
                                    for comp in result.chain
                                    if not isinstance(comp, Plain)
                                ]
                        except asyncio.TimeoutError:
                            logger.error(
                                "TTS timed out after %.1fs; sending text instead.",
                                self.tts_timeout_s,
                            )
                        except Exception:
                            logger.error(traceback.format_exc())
                            logger.error("TTS failed; sending text instead.")

            # 文本转图片
            elif (
                result.use_t2i_ is None and self.ctx.astrbot_config["t2i"]
            ) or result.use_t2i_:
                parts = []
                for comp in result.chain:
                    if isinstance(comp, Plain):
                        parts.append("\n\n" + comp.text)
                    else:
                        break
                plain_str = "".join(parts)
                if plain_str and len(plain_str) > self.t2i_word_threshold:
                    render_start = time.time()
                    try:
                        url = await html_renderer.render_t2i(
                            plain_str,
                            return_url=True,
                            use_network=self.t2i_use_network,
                            template_name=self.t2i_active_template,
                            endpoint=self.ctx.astrbot_config.get("t2i_endpoint")
                            or None,
                        )
                    except BaseException:
                        logger.error(
                            "Text-to-image rendering failed; sending text instead."
                        )
                        return
                    if time.time() - render_start > 3:
                        logger.warning(
                            "Text-to-image rendering took more than 3 seconds. Disable "
                            "text-to-image mode in the WebUI if it is too slow.",
                        )
                    if url:
                        if url.startswith("http"):
                            result.chain = [Image.fromURL(url)]
                        elif (
                            self.ctx.astrbot_config["t2i_use_file_service"]
                            and self.ctx.astrbot_config["callback_api_base"]
                        ):
                            token = await file_token_service.register_file(url)
                            url = f"{self.ctx.astrbot_config['callback_api_base']}/api/file/{token}"
                            logger.debug(f"Registered: {url}")
                            result.chain = [Image.fromURL(url)]
                        else:
                            result.chain = [Image.fromFileSystem(url)]

            # 触发转发消息
            if event.get_platform_name() == "aiocqhttp":
                word_cnt = 0
                for comp in result.chain:
                    if isinstance(comp, Plain):
                        word_cnt += len(comp.text)
                if word_cnt > self.forward_threshold:
                    node = Node(
                        uin=event.get_self_id(),
                        name="AstrBot",
                        content=[*result.chain],
                    )
                    result.chain = [node]

            # at 回复 / 引用回复仅适用于纯文本或图文消息
            can_decorate = all(
                isinstance(item, (Plain, Image)) for item in result.chain
            )
            if can_decorate:
                # at 回复
                if (
                    self.reply_with_mention
                    and event.get_message_type() != MessageType.FRIEND_MESSAGE
                ):
                    result.chain.insert(
                        0,
                        At(qq=event.get_sender_id(), name=event.get_sender_name()),
                    )
                    if len(result.chain) > 1 and isinstance(result.chain[1], Plain):
                        result.chain[1].text = "\n" + result.chain[1].text

                # 引用回复
                if self.reply_with_quote:
                    result.chain.insert(0, Reply(id=event.message_obj.message_id))
