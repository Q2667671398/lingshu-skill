# 📜 更新日志

> 每一次值得说的进化都会记在这里。

## v3.0.3 · 工具文本上下文折叠、前台手机单轮限流与抖音笔记兼容（2026-11-06）

- 新增 `trim_tool_text_contexts` 与 `trim_tool_text_history`：保留最近工具结果原文，将较早的 `role="tool"` 结果折叠为短占位符并保留 `tool_call_id` 配对结构，同时清理内联长串图片 base64；在 `ToolLoopAgentRunner._sanitize_contexts_for_provider` 与 `guard_phone`（`on_llm_request`）中同裁截图与工具文本，`handle_api_error` 超限重试先 `strip_image_parts` 再折叠工具结果，且后续重试无变化时委托原生错误处理器避免空转。
- 前台主人私聊手机工具增加单回合上限：插件与 `ops.py` 新增 `phone_tool_calls_per_turn=40`、`phone_screenshots_per_turn=8`（及 `NUMERIC_LIMITS`），按 `(unified_msg_origin, message_id)` 有界计数，覆盖 `GuardedPhoneTool.call`、`df_phone_observe` 与 `df_phone_act`；后台 `df_run_id` 活动仍走原有运行预算不叠加。
- `df_activity_note` 兼容抖音视频笔记：`cid` 改为可选，无 `cid` 时按当前私聊已核实的 `kind='douyin_video'` 经历（真实 `video_key` 如 `dy:...` 或 `episode_id`）校验观察证据与位置后保存笔记；严禁把搜索关键词、标题或序号当作 `bvid`，B站视频仍要求 `bvid+cid`。
- 补充前台私聊虚拟手机与抖音能力自我认知：`guard_phone` 仅对主人会话动态注入 `capability_context`（明确同一台虚拟手机同时装有 B站 `tv.danmaku.bili` 与抖音 `com.ss.android.ugc.aweme`，所有手机查看/控制工具对抖音同样有效，需要离开应用界面时先用 `get_current_app`/`df_phone_observe` 查看再用 `go_home` 或 `df_phone_act(action="go_home")` 退回手机桌面并核实，不夸大声称已杀进程或强制停止播放，同时提示当前已开启的 `df_phone_*`/`df_douyin_*`/`df_learn_evaluate`/`df_knowledge` 工具）。
- 新增5项回归测试；全量 `test_*.py` 798项 OK（20 skip）。

## v3.0.2 · 手机坐标边界与等待上限（2026-11-06）

- 修复 `PhoneAgent.act` 把点击边界写成 1440×2560（实际 720×1280）；越界点击直接拒绝并提示真实屏幕尺寸，swipe 坐标同样校验。
- 前台 raw `tap` / `swipe` 工具增加边界校验；raw `wait` 最长 10 秒，避免超长等待堵住 MCP 会话。
- `phone_screen_width` / `phone_screen_height` 加入插件与 ops 默认配置（720×1280），可用 ops 调整。
- 新增手机越界点击测试；全量 `test_*.py` 793项 OK（20 skip）。

## v3.0.1 · 抖音/手机经历、假设好奇心与聊天后唤醒（2026-11-06）

- 抖音视频与手机观察经历并入统一 `episodes`，可作为目标推进与自我表达的当前来源。
- 知识门控产生的 `hypothesis` 卡片进入 `curiosity_threads`；探索候选可据此生成“假设验证”方向。
- 新增 `curiosity_wakeup_due`：探索后的聊天话题或待验证假设写入 `curiosity_spark`，在下一次调度 tick 提前唤醒一次活动，不等周期定时器；同一火花只唤醒一次。
- `SelfExpression` 快照/备忘纳入抖音兴趣、前台打断与假设线程。
- 新增5项定向测试；全量 `test_bili_*.py` 652项 OK（15 skip）。

## v3.0.0 · 攒着没发的话、聊天探索线索与好奇心反哺（2026-11-06）

- 后台生活轮次调用 `df_share_thought` 或 `df_workshop(..., action="share")` 被联系时机/留白/每日分享额度门禁拦截时记录 `share_held` 事件；`SelfExpression.snapshot` 只读暴露最近48小时最多2条 `held_thoughts` 并在中文备忘中提示下次私聊自然提起，若随后发出/状态不确定或作品修订/来源失效则自动清除。
- 主人私聊日常提及的在玩/在看/想聊话题通过 `LifeState.record_chat_topic` 记入 `owner_chat_topic` 事件（不写 `episodes` 或长期记忆）；`LifePlanner.choose` 的 `explore` 候选汇总正向显式偏好与近期聊天话题为 `chat_topics`（`subject_kind="user"`，+4分），保持 `decision["topic"]` 与 `own_interest_evidence` 严格归属自身观察（`subject_kind="agent"`）。
- 跨日项目已完成阶段回看的 `next_question`（`project_followup`）与独立已完成目标核实作品的 `## 待核实`（`work_open_question`，支持 `read`/`video` 有效来源）汇总为 `curiosity_threads`，同时供 `SelfExpression` 展示与 `LifePlanner.choose` 在无未展开视频兴趣时优先作为探索方向（+6/+5分）。
- 前台主人私聊新增 `ExpressionCadence`：每条消息最多自动提供1条 `held_thoughts` 摘录，同一候选6小时冷却；同一消息的工具续轮复用原选择，曝光只写 `held_thought_context` 的 `context_only` 状态，不删除原记录、不标记已发送。全量 `test_*.py` 768项 OK（20 skip）。
- 运行加固：`once_at`/`next_check_at` 非法值不再让调度循环崩溃；手机健康检查连续3次失败才取消本轮；主人决策时间戳先按5秒容差解析，明显过期时给出回执而不是静默丢弃；bili 伴随 MCP 代理只允许 AstrBot 容器 IP 连接。
- 测试隔离：修复 `load_plugin()` 的临时 `sys.modules` 补丁误删 PIL 与插件子模块，导致 douyin/phone 在 `test_*.py` 全量顺序下串测失败的问题。
- v3.0.0 全量离线测试：787项 OK（20 skip）；发布预检10项通过、0警告。
- 无网只读容器（`dafeiyu-life-pilot-astrbot`，Python 3.12）定向测试 `test_bili_self_expression.py` 40项 OK、`test_bili_planner.py` 31项 OK，全量 `test_bili_*.py` 615项 OK（1 skip：Windows junction 专属测试）。未修改人格、审批、传输或运行配置，未部署。见 [SELF_EXPRESSION_V01.md](deploy/bili_activity/SELF_EXPRESSION_V01.md)。

## 未发布 · 近况回顾拟人化衔接与中文备忘（2026-11-06）

- `SelfExpression.snapshot` 只读并入当前作息节律（`rhythm` 时段、原因、已活动分钟数）与跨日项目摘要（`projects` 阶段进度、回看状态、后续问题与到期任务 `review`/`advance`），未初始化项目表时不建表、不写备份。
- 中断记录关联同轮 `trigger` 活动类型与 `goal_selected` 目标标题；当 `cancelled` 运行匹配受控白名单 `foreground_preempt` 事件时附带打断说明，并在15分钟窗口且无后续运行完成时提供 `recent_preemption`，支持被主人找她/操作打断后的自然接话。
- `SelfExpression.context` 注入提示词由原始 JSON 改为紧凑中文备忘，剔除 `body_hash`、`check_episode_id`、`source_episode_id`、`episode_scan_limit` 等内部字段；`df_self_reflect` 工具与状态接口仍返回结构化 JSON。
- 无网只读容器（`dafeiyu-life-pilot-astrbot`，Python 3.12）定向测试 `test_bili_self_expression.py` 37项 OK（0 skip），全量 `test_bili_*.py` 610项 OK（1 skip：Windows junction 专属测试）。未修改人格、审批、传输或运行配置，未部署。见 [SELF_EXPRESSION_V01.md](deploy/bili_activity/SELF_EXPRESSION_V01.md)。

## 未发布 · 隔离记忆联查验收准备（2026-11-06）

- 新增只读检查器 `python -B -m deploy.bili_activity.pilot_memory_check --pilot-dir .life-pilot/v01`：核对固定版本/模型ID、源码与活动配置哈希、QQ/活动/记忆访问与清理开关，密钥只报告是否存在。状态 `invalid_input`/`blocked_config` 退出3，`missing_keys`/`models_disabled`/`models_partly_enabled` 退出2，`config_ready` 退出0；始终 `live_verified=false`，运行时八项UNVERIFIED。
- 审查修复：符号链接环在旧Python上抛出的RuntimeError按 `invalid_input` 处理；`invalid_input` 时清空部分检查结果与密钥状态。新增junction、链接环、部分结果清理和检查期间配置变化测试，共32项。
- 实际结果：对隔离目录运行为 `missing_keys`（退出2），8项静态检查通过，235个源文件0不一致。定向测试 Windows 32项 OK、5 skip（符号链接/junction权限），WSL 32项 OK、1 skip。Windows全量 `test_bili_*.py` UNVERIFIED：206项中19个模块缺 `mcp` 无法导入、1项部署测试受宿主bash路径影响失败、14 skip，原测试venv已不存在。
- 未填写密钥、未调用模型/嵌入、未写入/回读/召回记忆，未启动QQ或活动。未来联查步骤与通过条件见 [PILOT_MEMORY_ACCEPTANCE_V01.md](deploy/bili_activity/PILOT_MEMORY_ACCEPTANCE_V01.md)；验收准备完成不等于真实链路通过。

## 未发布 · 房间近况同步收尾（2026-11-06）

- 完成可关闭的60秒只读同步验收，页面隐藏时暂停，手动与自动读取共享在途请求；失败保留原记录与快照时间，不改变角色区域、镜头或机器人活动。
- 修复桌面手记内层列表和手机整页在新记录到来时的读位跳动；改用按到期时间安排的单个定时器，避免轻微定时误差漏掉一轮。
- Windows观测台98项通过；Chrome最终34项通过，包含先失败后通过的两个反例、手机阅读位置及原星海/动画回归。真实源连续同步、模型与QQ仍未验证，未部署。见 [ROOM_SYNC_V01.md](deploy/memory_observatory/ROOM_SYNC_V01.md)。

## 未发布 · 隔离实例模型与记忆安装

- 在本机隔离AstrBot内安装固定LivingMemory 2.7.0-beta.2（`28698d3`），预填DeepSeek Flash和硅基流动bge-m3模型条目；密钥留空、模型禁用。保留会话/人格隔离，空白名单阻止采集与记忆工具，原活动配置不变。
- 实际插件加载、依赖检查、配置验证、空白名单拒绝及真实写入工具在处理前拒绝均通过；235个源文件哈希一致、本机HTTP 200。完整记忆引擎因缺模型未就绪，真实调用/记忆/QQ未验证。安装前配置及镜像保留，未改云端。见 [PILOT_MEMORY_V01.md](deploy/bili_activity/PILOT_MEMORY_V01.md)。

## 未发布 · 本机隔离试运行

- 准备被Git忽略的 `.life-pilot/v01/`：独立数据目录/本机端口、当前插件副本、默认全关配置、手动QQ profile、文件哈希清单和现场说明；未复制生产配置、凭据或数据库。
- 完成29文件清单、28载荷哈希、源码与语法、隔离路径和关闭门禁的静态核对；清单保留为2026-11-03准备时的快照。
- 2026-11-04经主人明确授权，在现有WSL Ubuntu 22.04中安装Docker Engine 29.9.2 / Compose 5.7.0，构建并启动独立AstrBot 4.29.0。Windows本机HTTP 200、浏览器登录页、插件加载及 `pip check` 通过；验证重复启动复用保活进程、停止再启动并保留数据。新建本机启停脚本；QQ、自主活动与真实写入仍关闭，模型/QQ/LivingMemory真实联动未验证。未改云端。详见 [PILOT_V01.md](deploy/bili_activity/PILOT_V01.md)。

## 未发布 · 生活观察报告 v0.1

- 增加独立只读报告命令：显式指定隔离数据目录和项目ID，按同一数据库快照汇总阶段、运行日期/状态、模型额度记录和作品记忆队列；输出Markdown或JSON，不启动、恢复、批准或重试活动。
- 报告保留数据缺口、截断和未知结果，首次探索通过后续同轮经历关联；不输出正文、配置或账号，读取成功不代表真实主动性、LivingMemory召回或QQ通过。
- 新增16项离线测试并扩充跨日联查，提供模拟报告示例。Windows B站模块574项 OK（11 skip），WSL报告模块16项 OK；未部署、未读取真实账本。用法见 [LIFE_OBSERVATION_V01.md](deploy/bili_activity/LIFE_OBSERVATION_V01.md)。

## 未发布 · 跨日生活联查与项目收尾修复

- 修复同一回看轮次保存最终回看后，下一次模型请求因项目已完成而将整轮误记失败的问题。仅本轮成功保存的回看允许正常收尾，仍阻止后续模型/工具调用；关闭活动、外部完成、普通运行错误保留原阻断/失败结果。
- 新增6项联查，保留实际控制器、原生Agent入口和预算适配器，模拟三日期及账本重开；核对阶段判重、跨日额度、作品来源/版本、只读项目册、近况依据和记忆队列不重复派发。
- Windows B站生活模块558项 OK（11 skip）；房间/记忆Windows 98项 OK、WSL 98项 OK（1 skip）。WSL生活模块依赖缺失、真实模型/QQ/LivingMemory与数日主动延续未验证。未部署、未开启真实配置；证据与现场清单见 [LIFE_JOURNEY_V01.md](deploy/bili_activity/LIFE_JOURNEY_V01.md)。

## 未发布 · 房间项目书架 v0.1（本地、只读）

- 书架增加跨日项目册：主题、阶段时间线、作品版本与正文摘页、完成后的收获/局限/新问题；保留单件作品列表，手机布局与键盘展开可用。
- 原只读活动适配器增量投影项目，不导入可迁移/恢复状态的插件；旧库、来源修订、版本不符、关闭功能和旧快照分别说明，不把记录当作事实核验或真实执行。
- 同步及切换角落保留所选项目与章节开合；角色、镜头、望窗/睡姿八帧和星海60秒同步未改。未新增活动或写接口；房间新增可关闭的 60 秒只读自动同步（默认开启，复用 `/api/room/refresh`，页面隐藏时暂停）。
- 新增13项项目读取测试；Windows/WSL观测台各98项通过（WSL 1 skip），Chrome虚构浏览器27项通过。真实项目库/SSH/LivingMemory联动未验证，未部署。详见 [PROJECT_SHELF_V01.md](deploy/memory_observatory/PROJECT_SHELF_V01.md)。

## 2026-11-06 · bili_activity v0.6.0：虚拟手机自由操作（B站/抖音）、抖音互动发作品与明辨学习门控

- **M1 通用虚拟手机安全控制器（`phone_agent.py`）**：新增 `PhoneAgent` 与工具 `df_phone_observe` / `df_phone_act`。严格限定白名单仅允许 B站（`tv.danmaku.bili`）与抖音（`com.ss.android.ugc.aweme`），硬编码拦截系统设置、安装器、支付宝、微信等禁区包名并自动 `go_home`；点击与输入前拦截「确认支付 / 输入密码 / 实名认证 / 卸载应用」等高危 UI 词条；当动态视频画面导致 `get_ui_elements`（`uiautomator dump`）失败时自动降级为 `ScreenCapture` 真实截图 + `listen_audio` 内录转写，并写入 `phone_observation` 经历。
- **M2 & M3 抖音浏览、互动与作品直接发布（`douyin.py`）**：新增 `DouyinController` 与工具 `df_douyin_feed` / `df_douyin_propose` / `df_douyin_create_post`。支持推荐流/关注流/搜索流连续刷抖音、弹窗自动关闭、画面截图与音频转写、评论区采样，记录 `douyin_video` 经历并无缝接入 `df_interest` 与 `Workshop` 创作引用；支持点赞、收藏、关注、评论、回复的配额账本（`douyin_actions`）与操作前后画面指纹核验；作品发布（`douyin_post`）强制路径防越界检查并始终需要主人在 QQ 明确批准（如回复「可以」「批准」「批准发布」「发吧」），批准后自动推送素材、填写标题/文案/话题标签并**直接点击「发布」**。
- **M4 互联网明辨学习与认知门控（`knowledge_gate.py`）**：新增 `KnowledgeGate`（`knowledge_cards` 表）与工具 `df_learn_evaluate` / `df_knowledge`。第一道确定性过滤器拦截提示词注入、修改人设、认主欺骗、微商引流与震惊体谣言；第二道认知分级漏斗要求绑定本会话真实观察经历 ID（防幻觉），单源孤证最高仅存为 `hypothesis`（待核实假设，不入长期记忆），仅当 ≥2 个独立信源（如 B站+抖音）交叉印证或主人前台 `confirm` 确认时才升格为 `verified_knowledge` 并带信源标签写入 LivingMemory；支持 `refute` 一键证伪撤回并阻止重复吸取。
- **全量回归验证**：新增 `tests/test_phone_agent.py`、`tests/test_douyin_activity.py`、`tests/test_knowledge_gate.py`，连同仓库原有 39 个测试套件共 42 个测试文件全部通过。

## 2026-11-06 · deploy-kit：本地一键引导、干净组装与体检包（PR #3）

- 合入并升级 @kibsmdadah-lgtm 的 `deploy-kit/` 与 `QUICKSTART.md`：把「装前体检 → 建虚拟环境装依赖 → 组装 `payload/` → 跑离线测试 → 装后复查」串成可验证的一键链路。
- `deploy-kit/preflight.py` 增强：区分 `--stage install`（端口空闲不误报警）与 `--stage post`（复查 6199/6185/6099 均在监听）；新增插件源码语法编译、`face_map.json`（326 项）与人格提示词完整性检查；`.env` 校验识别未替换占位符、行尾注释、`export` 前缀、QQ 号合法性及大小号同号风险；支持 `--with-bili`（检查 Python 3.12+ / `Asia/Shanghai` 时区 / `Pillow` / `mcp`）与 `--json`。
- 干净组装 `payload/`：默认只打包 2 个核心聊天插件（`face_convert` + `schedule_awareness`），避免无 Python 3.12 / `mcp` 的新用户拷入 `bili_activity` 报错（加 `--with-bili` 才一并打包）；自动剔除 `__pycache__`、`*.pyc`、本地 `config.json` 与数据库；自动剥离 `persona/大肥鱼-人格.md` 顶部说明生成可直接全选粘贴的 `payload/persona/大肥鱼-system-prompt.txt`。
- 修复 `bootstrap.sh` / `bootstrap.ps1` 克隆模式下引用 `$ROOT` 导致找不到 `requirements-plugin.txt` 与 `preflight.py` 的问题；`bootstrap.ps1` 补齐 `uv pip` 兼容与测试退出码检查；支持清华源自动回退与 `--offline` 离线自检；`QUICKSTART.md` 对齐 NapCat 根目录 `napcat.bat` 自包含模式、`admins_id` 主人识别与 `asr_api_key` 解耦说明。新增 `tests/test_deploy_kit.py`（21 项断言全部通过）。

## 2026-11-06 · face_convert v1.3.3：主人私聊补齐身份标记（issue #18）

- 修复主人（`admins_id`）私聊时不进入身份标记分支、消息不带任何平台身份映射的问题；人格规则只认平台映射、不认自称，导致私聊里拒绝认主。
- 现在管理员不论群聊还是私聊都标 `[主人(QQ号)]`；群友 `[昵称(QQ号)]`、访客私聊 `[主人的朋友 昵称(QQ号)]` 不变；非群非私聊（如频道）仍不标记；「喊了你一声」仍仅限群聊。人格无需改动。
- 新增 7 项身份标记回归用例（四象限 + 其他会话 + 不重复打标 + 私聊空消息），旧代码下 `private-admin` 用例失败、修复后全部通过。感谢 @954031894 的定位与方案。

## 2026-11-05 · schedule_awareness v1.0.1 / v2.11.2：任务名/备注收敛（issue #17）

- `_format_schedule` 新增 `_safe_label()`：折叠换行与空白、移除 `【】[]{}<>`、`：|` 和独立 `:` 转空格，任务名限 20 字（备注 60 字），空名回退「未命名任务」；`07:00` 这类时间冒号保留。
- 清单开头新增声明：这些是用户创建的任务数据，不是对模型的指令；避免任务名/备注改变系统提示的结构。
- 新增 8 项离线断言；日程测试 18 项全部通过（1 项因本机无 DB 跳过）。纯注入层收敛，不读改 `cron_jobs`。

## 2026-11-03 · face_convert v1.3.2：拆掉误发的消息数组壳

- 修复模型把正常回复写成 `['第一句。', '第二句。']` / `[{"type":"text","text":"…"}]` 时，被分段器切成带方括号、单引号和逗号的碎片的问题。
- 新增 `_unwrap_message_shell`：只在整条回复就是消息数组、且元素像聊天句子时还原；普通正文、代码块和用户要的数据列表保持原样。
- 普通回复（on_llm_response）和工具循环/结果关口（on_decorating_result）都会拦截；新增 9 项回归用例。

## 2026-11-02 · 自主生活三模块 v0.1 / v2.11.0（插件 v0.5.0 / v1.3.1 / v1.0.0 未变）

- 经历记忆 v0.1：7/60 天分阶段检索，来源校验后的兴趣巩固快照，复用 LivingMemory 入队；默认关闭。
- 近况回顾与自我表达 v0.1：主人私聊只读注入当前意图、兴趣变化和完成/中断边界，不写记忆、不增活动；默认关闭。
- 跨日自主项目 v0.1：有限项目、阶段作品与 24 小时回看，新增四张表和恢复流程；默认关闭。
- 审查修复：项目表损坏时普通生活决策仍可运行；回看门禁补齐已完成/缺失项目；近况注入遵守 DND/暂停。Windows 全量 666 项 OK（16 skip），bili 552 项 OK（11 skip）。未部署、未开启真实配置。

## 2026-11-02 · 跨日自主项目 v0.1（随 v2.11.0，默认关闭）

- 将已有目标/作品组织成有限项目，默认最多同时两个、每个三阶段；完成24小时后参加原生活调度的回看候选，收获与局限绑定作品版本、正文哈希及来源，来源失效停止自动延伸。
- `df_project` 管理，`df_life_status.projects` 查看索引。回看仅使用已有资料，不占手机、不提供公开操作或联系工具；下一问题只创建待做目标，留到下一轮。沿用作息、主人暂停、免打扰和原预算。
- 增量表首次创建前备份；下一阶段预留与目标稳定来源键支持重启恢复，重放不重复创建。不开新调度或发布通道，不直接写长期记忆；房间和网页作品集尚未增加本阶段入口。
- 新增34项离线测试通过；Windows全量552项 OK（11 skip）。真实模型/QQ/LivingMemory、长期运行与Linux未验证，未部署。配置、恢复限制和现场验收见 [PROJECTS_V01.md](deploy/bili_activity/PROJECTS_V01.md)。
- 审查修复：项目表不完整/未来版本时项目功能降级，不再阻断普通生活决策；回看门禁对缺失或已完成项目报权限错误。

## 2026-11-02 · 近况回顾与自我表达 v0.1（随 v2.11.0，默认关闭）

- 新增只读近况回顾：当前意图、前后两个窗口的自身兴趣记录、带当前来源的目标完成记录和运行中断边界；单次/重复/矛盾观察不升级成稳定性格，运行完成不等于目标完成。
- `df_self_reflect` 与现有原生 Agent 对话钩子接入，沿用人格和已有情绪上下文，仅相关话题自然引用；公开回复监听不带私聊回顾。回顾不直接写记忆、发消息或创建活动。
- 复用经历记忆的兴趣来源校验，未改审批、预算、传输、人格和 EmotionAI；开关与窗口可配置，缺省关闭、关闭回退、配置元数据保留。
- 新增33项离线测试通过；Windows全量518项 OK（11 skip）。真实模型/QQ/在线插件联动与Linux未验证，未部署。详见 [SELF_EXPRESSION_V01.md](deploy/bili_activity/SELF_EXPRESSION_V01.md)。
- 审查修复：近况注入遵守 DND 与生活暂停，不再在静默时段追加私聊回顾。

## 2026-11-02 · 经历记忆 v0.1（随 v2.11.0，默认关闭）

- 普通生活经历按7/60天分为细节、概要、淡出默认回忆；主人明确偏好、未完成目标及作品/方法证据保留。原始账本不删，按ID可追溯修订，关闭开关恢复原查询。
- 相同兴趣由不同实际读取视频支持后生成有来源和日期的巩固快照；重复浏览/分P不增加独立证据。复用 LivingMemory 写入队列，限制档位和间隔，发送前重查来源、开关与身份；并发只领取一次，未知不重试。
- 前台/生活轮次的近期记录使用同一策略；单次观察与运行自述开启后只留本地，明确偏好/已检查作品沿用原写入链。不叠加全库衰减、不修改星海模拟或真实上游记忆。
- 新增28项测试；Windows全量485项通过（11 skip）。WSL缺少mcp，Linux未验证；真实LivingMemory/QQ与长期效果未验证。配置、回滚及现场清单见 [MEMORY_POLICY_V01.md](deploy/bili_activity/MEMORY_POLICY_V01.md)。未部署、未开启真实配置。

## 2026-11-01 · 生活节律 v0.1 / v2.10.0（插件 v0.5.0 / v1.3.1 / v1.0.0 未变）

- 既有生活决策增加默认关闭的上海作息：晨间优先续篇、睡前仅整理已有作品、睡眠时段和近期活动较多时留白；不新增定时器、模型或数据库表。
- 依据同一会话已结束运行的经过时间累计，重叠去重、跨日不清零；未知/未来记录不冒充已完成活动。运行时长受原预算和节律截止时间共同约束，准备耗时跨过边界后不再启动工作。
- `df_life_status`、原决策账本和房间总览/休息角展示节律理由。保持日期和只读边界，不把工程指标说成体力/情绪，不生成休息经历。
- 新增22项节律离线测试；开启节律前复用配置范围/睡眠窗口校验，坏配置不能通过 switch 开启；配置与启停、完整回归、现场验收及回滚见 [LIFE_RHYTHM_V01.md](deploy/bili_activity/LIFE_RHYTHM_V01.md)。未部署或开启真实配置。
- 房间望窗/睡姿尾根修复：八帧图集回填并按画布基线对齐，暂停/减少动画保持第 0 帧；浏览器 25 项通过。
- 提示词修正：链接不再称为“代码片段”或套反引号；活动读取接口时不硬配手机截图，截图前须先在手机上打开目标页。

## 2026-10-31 · face_convert v1.3.1 / v2.9.1：语音转写优先本地 WAV（修复 NapCat retcode 1400，issue #16）

- `_transcribe_voice` 优先级改为：AstrBot PreProcessStage 已生成的本地 WAV（`rec.path` / `rec.file`）→ 语音直链下载 → 最后才调 NapCat `get_record`。
- 新版 NapCat 的 `get_record` 加强 PayloadSchema 校验，会返回 retcode 1400；本地文件优先后不再触发，同时省去一次 NapCat 转码往返。
- 新增 3 项语音优先级回归测试（本地 WAV / 直链 / get_record 兜底）；视频+语音测试 11 通过、5 跳过（本机无 ffmpeg）。
- 记忆星海房间：点击她当前所在的区域不再重播走动/切换动画，只有真正切换区域才响应。
- 隐私清理：tracked files 中的真实 QQ 号、云主机 IP、B站 UID 改为占位符。

## 2026-10-30 · 记忆星海 v0.3 / v2.9.0（插件 v0.5.0 / v1.3.0 / v1.0.0 未变）

- 星图由矩形分类格改为深蓝星域：每类固定方向、深度和半径，节点按 ID 哈希稳定落点；新增星尘、星云与相机透视，近大远小、按深度绘制。
- 拖动缓慢环视、滚轮推拉；点击悬浮星域名平滑靠近，再点一次或 `⌾` 返回全景；保留 2D 正交阅读；60 秒同步保留相机、选中、筛选和模拟天数，切换作用域清空旧内容。放大范围放宽到 3D 最近 0.65、2D 6 倍，星域聚焦更近。
- 关联线默认压淡，选中后点亮直接关系与跨星域光弧；直接关联节点也加同色环并保持完整亮度，密集星域中能一眼找到。再次点击同一节点取消选中。只用现有 `edges`，不按位置新增关系。
- 遗忘模拟滑杆增加本地即时预估（仍在服务端结果回来后被同一公式校正），淡出缓动收紧，拖动时星点跟随更紧。
- 桌面快捷方式默认带 `--life-ssh`，双击同时只读连接记忆与活动账本；已有真实服务直接复用，并修复 Windows 关闭端口被误判为“占用”的问题。
- 隐私清理：当前文件中的真实 QQ 号、云主机 IP、B站 UID 改为占位符；ops_mcp 的 `webui_info` 与 Bili 自启脚本改读环境变量或主机文件，不再内置真实账号/IP。
- 房间：点击她当前所在的区域不再重播走动/切换动画，只有真正切换区域才响应。
- Windows/WSL 各 83 项单测通过；浏览器 22 项通过（含星域稳定性、取消选中、关联节点同色环、刷新保相机、星域聚焦、放大范围、移动端）。未部署。

## 2026-10-30 · 桌面快捷方式接入活动账本（v2.9.0）

- 启动器新增 `--life-ssh`；安装脚本把快捷方式参数改为 `-B -m deploy.memory_observatory.launcher --life-ssh`，双击即同时只读连接记忆与活动账本。
- 已有真实服务在运行时仍然直接复用并打开，不重复启动；旧快捷方式重跑安装脚本即可原地升级。启动器新增 2 项测试。
- 修复 Windows 上无服务监听时连接超时被误判为“端口占用”的问题：超时按未启动处理，快捷方式可正常拉起服务。

## 2026-10-30 · 她的小小房间 v0.2 / v2.8.0

- 接入已确认的大肥鱼鲸鱼娘女仆形象与六组动作，总览待机、走动、写字、阅读、望窗、睡觉；区域切换平滑特写，窗景跟随上海时间。
- 房间和记忆星海统一浅蓝奶白风格；记忆按类型/形状分区，点亮直接关联，遗忘模拟连续过渡；60 秒同步保留当前作用域、筛选和实验。
- 审查修复：快照年龄改用本机单调时钟、角色图集整数格+透明隔断、`graph.js` 显式三元、被拒请求先排空请求体、观测台 README 对齐 v0.2。
- Windows 81 项通过；WSL 81 项通过（1 skip）；虚构浏览器 18 项、真实只读浏览器 7 项通过。实际连接 LivingMemory 与活动账本；动画不代表真实执行，未更改记忆/生活策略、未部署。见 [ROOM_V02.md](deploy/memory_observatory/ROOM_V02.md)。

## 2026-10-30 · 她的小小房间 v0.1（未发布）

- 记忆星海新增 `/room`：本地 SVG 深海小屋与鲸鱼，四个角落展示已有目标、作品、选择、休息和联系记录；适配窄屏、键盘与减少动画。
- 新增显式只读活动来源：启动时指定本地目录或固定 SSH 源，限定已配置主人私聊；不导入会恢复/迁移状态的插件 Store，不读取凭据或回写数据库。
- 区分选择与执行、运行结束与目标完成；缺来源显示未知，同步失败/超时显示旧快照。修复旧导航处理器误绑定新页面链接的问题。
- Windows 79 项通过，WSL/Linux 79 项通过（1 skip）；浏览器 14 项通过。真实活动源未连接，未改机器人开关、未部署。详见 [ROOM_V01.md](deploy/memory_observatory/ROOM_V01.md)。

## 2026-10-30 · 部署补丁：固定 NapCat 设备指纹（未发布）

- `deploy/compose.yaml` 给 napcat 固定 `hostname`，避免容器重建后设备名变化被 QQ 当成新设备；machine-id 固定以可选注释提供，附创建命令与「源文件不存在会变成目录」的警告。
- `deploy/README.md` 补设备名/指纹排障：hostname、machine-id、`device.json` / `session.token`、`napcat/qq` 四个来源，以及固定后的代价（重建需重扫一次码）。
- 纯部署配置改动，不改运行时代码；未部署云端、未重建容器。

## 2026-10-30 · 主动联系协调 v0.1（已部署）

- 生活后台分享与 proactive_chat 增加默认关闭的共享联系账本：上海日额度、跨日间隔、未回应限制和主人聊天后留白；不增加定时任务，不改原审批和活动预算。
- 整次 TTS/分段只预留一次；生成前检查条件、每次派发前复查，未知发送不授权自动补发；社区 bool 回报与 QQ 消息 ID 分开记录。
- 社区补丁按具体源码哈希校验，拒绝不兼容版本，提供只读检查、备份与失败恢复。保留原联网功能与传输实现。
- 新增 32 项离线测试通过，全量 435 项通过（11 skip）。初始基线一次旧方法复用测试错误及后续通过均记录在 [CONTACT_V01.md](deploy/bili_activity/CONTACT_V01.md)。2026-10-30 已部署云端并开启（额度 1/120/5/1），社区补丁已安装；真实 QQ 和 Linux smoke 仍未验证。

## 2026-10-29 · EmotionAI 主对话去注入（云端补丁）

- 移除 `astrbot_plugin_emotionai` 每轮注入的假用户/假助手/假 system 三条测试样本；主对话不再出现强制 XML、空代码围栏或「星绘」身份。
- 情感更新改为独立 JSON 分析：主聊天仍用 `deepseek-chat`，分析失败/超时保留原值；情感维度、变化范围、黑名单和持久化格式不变。
- 清理 conversation 2/5/6 的旧伪造三连；`[PROTOCOL_ENFORCEMENT]`、`星绘`、`报告前辈` 全库零命中。
- 补丁与部署说明：`deploy/patches/emotionai_v3.4_separate_analysis/`。上游升级会覆盖，需重新应用。

## 2026-10-29 · 生活决策 v0.1 / v2.7.0

- 原活动调度内增加默认关闭的选择器：根据未完成目标、自身兴趣、已有作品和近期尝试安排研究、写作、探索或休息。
- 保存选择理由、候选和排除依据；`df_life_status` / `ops.py life-decisions` 查询意图与实际运行结果。休息不调用模型或设备，不发送 QQ，不生成经历/长期记忆。
- 重复内容、事件 ID、采集时间和轮末总结不充当新进展；保留跨轮冷却、目标审批状态、前台优先和原预算。
- 旧配置缺少新键时默认关闭；跨 proactive_chat 的联系协调、虚拟房间与记忆策略仍为后续阶段。发布时未部署；2026-10-29 已部署并开启 planner、`activity/periodic`，首轮真实决策 `writing` 完成（作品 r7，目标 completed）。

## 2026-10-29 · 记忆星海 v0.2.1 / v2.6.1（60 秒自动同步）

- 真实只读模式新增可关闭的「每 60 秒自动同步」：只在页面可见时触发、单飞、失败保留旧快照并标 stale。
- 自动同步不重置当前筛选、时间轴实验或选中记忆；仍只读、不写回、不刷新访问计数。演示模式不轮询。

## 2026-10-29 · 记忆星海 v0.2 / v2.6.0（LivingMemory 只读接入）

- 核对线上实际安装的 LivingMemory 2.7.0-beta.2 后，新增固定 SSH 只读适配器；不部署脚本、不调用会强化记忆的引擎召回接口。
- 星图展示真实文档、有效原子、文档与原子的来源关系；详情显示原库 TTL、访问/强化次数及最多 5 条实体关系。按会话与人格共同隔离，计划单独分类。
- 新增手动同步、失败保留旧快照、真实只读标识；仅在本机进程内保存快照，遗忘曲线和线索检索仍为模拟，不回写原库。
- Windows / WSL 各 48 项离线测试通过；演示浏览器 10 项、真实只读浏览器 6 项通过。详见 `deploy/memory_observatory/LIVINGMEMORY_V02.md`。

## 2026-10-29 · 记忆星海 v0.1 / v2.5.0

- 新增本地记忆观测台：深海风格记忆星图、2D 视图、经历时间线、遗忘模拟、线索召回、来源检查、快照导入、私聊/群聊隔离。
- 只读快照 + 策略模拟；未接入运行中的 LivingMemory，不改变 QQ 里的真实记忆；默认 35 条虚构演示记忆。
- 27 项 Python、10 项浏览器测试通过；B站 374 项回归通过；无新依赖。
- 运行：`python -B -m deploy.memory_observatory.server --port 8766`，浏览器打开 `http://127.0.0.1:8766`。

## 2026-10-29 · B站互动 v0.5 / v2.4.0（汇报层修正）

- 主人可见回复改为按动作的人话 summary：like/coin 不再出现 `accepted`/`visibility`/`like_ok`；评论/回复才报公开可见性，弹幕才报受理/公开池。
- 账本与 `/bili互动 状态` 保留原始诊断字段，但模型被明确要求不向主人念内部字段；弹幕的 `accepted` 不再被拿来解释点赞。
- 全量 374 项离线测试通过（11 skip）。

## 2026-10-28 · 语音与气泡解耦（v2.3.0，已部署）

- 自动语音改为**整条回复只合成一次**：显示气泡照常按语义分段，语音不再逐泡合成，
  表情夹在句子中间也不会反复重置语调。
- 新增 `respond_stage.py` 补丁：按语义气泡发送，表情并回同一句；**首条立即发送**，
  后续气泡之间才留间隔；私聊明确喊停（“等等 / 不是这个意思”）会取消上一轮剩余气泡。
- 语音参数按模型能力传：qwen-audio 走自然语言 instruction，CosyVoice 才传数值
  语速/音高；补齐超时、HTML 错误页/空音频校验，失败统一降级为文字。
- ASR / 视频理解凭证与 TTS provider 解耦：优先读插件 `asr_api_key` 或环境变量
  `DASHSCOPE_API_KEY`，旧 `dashscope_tts` provider 只作兼容回退。
- 文本橡皮擦收窄：`[NO_REPLY]` 只在整条回复就是暗号时静默；`((a+b))` 等表达式
  不再被当草稿删除；“看不清 / 没听清”等诚实说明保留；meta 清理先保护代码、链接和引用。
- `face_convert` 升至 v1.3.0；新增 `tests/test_chat_layout.py`，并扩展
  `test_face_rules.py` / `test_video_processing.py`。已于 2026-10-28 18:26 部署云端，
  AstrBot 适配器已连接、插件加载正常；语音实听与气泡节奏待真实 QQ 对话验收。

## 2026-10-27 · B站互动 v0.5 审查修复（仅本地）

- 修复 uncertain 永久占用提议槽位：新增主人两步确认恢复命令和只读 operations 摘要，保留原执行证据、配额及判重，不重发 POST。未发送时的权限拒绝、等待锁/间隔期间取消归为 blocked。
- 点赞改用 Web 路径及 1/2 参数；点赞/投币缺 buvid3 时通过 SPI 补齐并原子保留 Cookie 元数据，失败零 POST。状态新增 buvid3_present。
- 弹幕补 aid/rnd、99 字符边界和 WBI URL 签名；明确受理回执单独记录 accepted，XML 延迟不再永久阻塞新提议，也不冒充回读或公开成功。Executor 原代码不变。
- 评论列表改用 WBI 接口，保留默认 mode=3，匿名可见性使用 mode=2；未找到/匿名请求失败均为 unknown，不影响账号登录或冷却。投币核验和附带点赞分开报告，真实认证失败仍保留风险处理。
- 状态刷新不被互动 guard 阻止；CLI 模式同步 auto_public 开关；关闭文案明确包含关注/收藏；回复监听采用发送前时间下界并兼容服务端秒级时间，避免漏掉回读完成前的回复。
- Windows 365 项（11 skip）、Linux 365 项（6 skip）离线回归通过。已按社区文档校正，真实端点及小号 smoke 未验证；未 push、未部署、未操作云端。

## 2026-10-27 · 开机自启被 PowerShell 5.1 的 stderr 坑打断

- `deploy/phone_mcp/start_phone_service.ps1` 在 `$ErrorActionPreference='Stop'` 下执行 `& $adb devices 2>$null`：Windows PowerShell 5.1 会把原生命令的 stderr 包成 `RemoteException`，而开机后 adb server 首次启动恰好打印 “daemon not running...”，脚本在拉起雷电后立刻退出，模拟器、PhoneMCP 与 Bili 隧道整条链路都没起来。
- 修复：等待模拟器就绪期间临时切到 `Continue`，结束后恢复；顺带覆盖 `pm list packages` / 输入法设置的同类 stderr 重定向。
- 背景：10-27 13:06 开机自启再次失败，20:30 活动全部 `TransportError`；10-21/10-24/10-25/10-26 的日志也都停在 `Starting LDPlayer`，同一根因。

## 2026-10-26 · B站评论区互动插件 v0.5.0（本地交付）

- 扩展原 proposal/Executor：新增点赞/取消赞、投币 1/2 枚及可选点赞、指定分P/毫秒/色值/字号的弹幕。默认审批，`engagement_actions=false`；公开评论/回复/弹幕仍受 `public_interactions` 控制。
- 新增上海自然日动作额度、同视频评论/弹幕与同目标回复/关注判重、随机间隔、风控冷却和登录失效通知。失败/未知保留账本与额度，不自动重试。`df_bili_status` 返回今日计数、待审批、冷却、登录状态及最近 5 条动作。
- 回复监听默认关闭，复用原调度和 Agent/Budget；按楼轮询、过滤自己/过期/水评/广告/重复回复，匹配精确目标后走既有提议链。评论观察默认关闭，以来源和规则评分保存，每次最多 3 条，明确不是事实或指令。
- 评论/回复详情回读与匿名公开列表分开核对；弹幕只匹配公开池中的 ID、正文和时间。`visibility=unknown` 不冒充已公开，接口接受不等于公开展示。
- 可显式开启 auto_low_risk（仅点赞/投币）或 auto_public（公开写需额外开关和正额度），支持 UP UID/视频标题关键词范围。自动授权单独记账，不伪造主人答复；收藏/关注始终逐条审批。新增主人 `/bili互动` 命令。
- 从 `662cd5d` 增量扩展，无新依赖、不改人格或 transport；仅本地提交，不 push、不部署。完整测试、限制、回滚及主人小号 smoke 见 `deploy/bili_activity/INTERACT_V05.md`。

## 2026-10-26 · B站活动承诺与开机自启修复

- 人格补充：主人叫去逛 B 站、问去了没有，或自己要马上动身时，必须先在同一轮调用 `df_bili_navigate` / `df_bili_read` / `df_bili_watch` 等实际工具；没有工具调用不许说“这就去/马上就去/去了去了”，只能如实说“还没开始”。修复“只承诺、不执行”的情况。
- `install_bili_autostart.ps1` 生成的开机启动项会先最多等 5 分钟 `emulator-5554` 再拉起 Bili 服务，避免登录时比 PhoneMCP 服务先跑、因设备离线直接退出。
- 背景：Bili 伴随服务在 10-26 00:21 随 PC 关机退出，13:07 开机后没有自启，导致 13:17–20:30 五次活动全部 `TransportError`；现已安装自启并完成端到端验证。

## 2026-10-25 · 原生语音与截图上下文修复

- 显式语音 `tts_speak` 改走 AstrBot 原生 `dashscope_tts`（`qwen-audio-3.1-tts-plus` + 复刻音色），不再使用第三方路由插件的 SiliconFlow / MiniMax 音色；补丁见 `deploy/patches/tts_emotion_router_native_speak.diff`，升级该插件后需重打。
- 保留自动 TTS，概率从 `0.35` 调到 `0.08`（8%），显式点名语音不受影响。
- 修复手机截图把 base64 原图全部留在上下文、导致 DeepSeek 1M 上下文超限（真实错误：请求 1,547,735 tokens）：每次 LLM 请求只保留最新一张工具截图，较早截图替换为占位文字；主人自己发的图片不受影响。
- 人格补充：明确要求语音时必须真调用 `tts_speak`；没实际执行手机/外部操作前不声称“已经去玩”。

## 2026-10-25 · 头像素材 v3

- 用 18 张新立绘替换旧 `v1-六视图` / `v2-状态立绘`，统一 640×640 PNG。
- 新素材来自用户提供的 ChatGPT 生成图；旧素材的授权署名保留在 git 历史中，若重新分发请回查原提交。

## 2026-10-25 · 自主生活 v0.3.0 上线与真实 smoke

- 合并 PR #2（`32f8349`）到 main，v0.3.0 首次进入主线；随后合并 PR #4（`8781ac8`，工具 JSON 参数兼容）、PR #5（`6ddacd6`，多词 recall）和 PR #6（`f088fdd`，无空格中文二字窗口）。
- 修复真实 smoke 发现的问题：phone 工具 owner 隔离、raw Bili MCP 工具移除、失败 read 只写 `read_failed`、`ready/paused → completed`、`df_goal` 默认状态、`df_workshop` 幂等与参数兼容、`Workshop.check` 原子化。
- 云端部署 v0.3.0：AstrBot v4.29.0 加载成功，12 个 `df_*` 工具注册，SQLite schema v1；QQ 恢复，PhoneMCP 18 工具连接。
- 真实 smoke：life run `122ca7125a7a4635be2b3fbaac4555fa` completed（目标 `def033...`，2 条视频 + 弹幕/评论，截图回执 `1693155839`）；workshop work `f992...` revision 1（4 个来源，检查通过）；export/share 通过；手机离线写作 run `36e934...` completed，正确 `need_sources` 回 research，无手机调用。
- 测试：Windows/Linux 均 **215 项 OK**（Windows 11 跳过，Linux 6 跳过；mcp 1.26）。
- 未验收：跨日预算、真实账号写入/提议、LivingMemory 实际召回、browser-use MCP；`df_recall` 仍是词面检索，不宣称语义召回。

## 2026-10-25 · 自主生活插件 v0.4.0

- 新增 `df_method`：从已完成且来源有效的作品提炼研究方法，保存适用条件、最多 6 步文字建议、停止条件及来源版本，刚提炼时标为待复用。
- 方法尝试绑定另一个目标和固定版本，沿用原生 Agent、已有工具和预算。暂停后继续同一尝试；修改方法不会替换旧尝试的版本。
- 目标完成时回查尝试之后产生的新作品、不同内容来源及原始方法依据，重复调用、旧作品或模型自报成功不能增加次数。当前有效次数与历史记载次数分开，来源失效后重新计算。
- 运行中关闭开关或方法来源失效时阻止继续套用；退役保留历史。成功、失败与放弃记录进入原有按会话隔离的记忆队列。
- 新增 `methods_enabled=false`、只读方法及尝试查询。独立表新增前一致性备份，不修改原权限、配置和暂停任务。方法是文字资料，不是代码执行接口。
- 本次只完成代码和离线验证，生产升级及真实 Agent/QQ/记忆验收仍待现场完成，见 `deploy/bili_activity/LIFE_V04.md`。

## 2026-10-24 · 自主生活插件 v0.3.0

- 新增 `df_workshop`：根据当前私聊真实阅读经历创建研究笔记，保存不可覆盖的正文版本和来源，支持检查、受控 Markdown 导出和 QQ 私聊摘录分享。
- 笔记区分资料观察、自己的想法和待核实事项。来源被修订、缺失或属于其他会话时，拒绝导出和分享；完成创作目标必须重新检查最新版本，检查不等同于事实核实。
- 未完成作品接入原有调度、目标、模型/时间/分享预算；续写不依赖手机在线或手机锁，需要新资料则返回浏览阶段。每轮版本数也有持久化额度，重复调用不增加版本或重复发送。
- 检查通过的作品进展进入现有 LivingMemory 队列，保持主人偏好和她自己的作品分开。停止活动和重启保留草稿。
- 新增 `workshop_enabled=false` 和只读作品运维查询；原配置及暂停状态保留，新增表前一致性备份。启停、部署与现场验收见 `deploy/bili_activity/LIFE_V03.md`。
- 本次未升级生产，未将模拟 QQ/Agent 测试记作实机验收；游戏操作、可执行技能和自动代码修改仍在后续阶段。

## 2026-10-24 · 自主生活插件 v0.2.0

- 整合主线可靠性修复和 B 站活动分支，沿用原生 AstrBot Agent、人格、工具与 LivingMemory。
- 新增 `df_goal`、`df_recall`、`df_interest`：目标保留理由/下一步/检查点，经历追加保存并按会话隔离，自己的兴趣与主人明确表达分开。
- 重启后运行中目标暂停，恢复时重新观察设备；目标完成需要实际内容证据，失败摘要不能充当进度。
- 新增上海自然日的时间、模型调用、主动分享预算；前台手机请求优先，支持“暂停自主活动/继续自主活动”。
- 修复互动开关关闭时未执行却进入 uncertain 的问题；等待审批目标随拒绝/过期/结果核实更新，未知外部写入继续禁止重试。
- SQLite 升级前一致性备份；CLI 可只读查看目标、经历和预算。新增 `life_enabled=false` 开关，升级保留已有配置和暂停状态。
- 本次为代码交付及离线验证，未声称生产 QQ、账号写入或跨日运行验收通过。配置、升级与验收见 `deploy/bili_activity/LIFE_V02.md`。

## 2026-10-23 · v1.8.2 自愈不再看日志时间窗，也不动别人的连接

- 连接判定改为容器内 6199 端口的 ESTABLISHED 连接（`docker exec astrbot cat
  /proc/net/tcp{,6}`），拿不到容器内视图时退回“日志里最后一条连接/断开记录”。
  修掉两处误判：连上后又断开仍被判正常；连了 3 分钟没新日志被误判异常。
- 修复只动指向 AstrBot(:6199) 的客户端，并逐条保留原 `enable`；不再把所有
  `websocketClients` 统一置 False 再置 True（那会把有意关闭的连接永久打开）。
- 修复超时返回非零；“30 秒内未重连成功”文案保留，`backup.sh` 的退出码和
  文案两道检查都能接住。
- 新增 `tests/test_heal_ws.py`：23 项纯标准库检查，覆盖 /proc 解析（IPv4/IPv6、
  LISTEN vs ESTABLISHED）、日志兜底的先后顺序、目标筛选、enable 还原，以及
  无目标 / 目标关闭 / 未重连三条失败路径。

## 2026-10-23 · v1.8.1 备份/启动脚本不再“假成功”

- 审查发现两处 P1：`deploy/backup.sh` 恢复容器和 `heal_ws.py` 都挂了 `|| true`，
  打包成功而 AstrBot 没起来也返回 0；`start_phone_service.ps1` /
  `start_browser_service.ps1` 用 `pgrep -f proxy.py` 判断，ssh 远端 shell
  自己的命令行就含该字符串，服务没跑也会匹配成功、照样报 OK。
- `backup.sh`：拉起失败 / 容器非 Running / heal 报错 / 30 秒内未重连 → 记
  `[ERROR]` 并非 0 退出；Ctrl-C/SIGTERM 也走同一条恢复路径；备份前容器本就
  停着则跳过停止/恢复，不会顺手把它拉起来。
- 启动脚本：改按监听地址判断（proxy 在 `172.18.0.1:8009/8010`，反向隧道在
  `127.0.0.1:8009/8010`），启动后等端口最多 10 秒，失败返回非零并带日志尾巴；
  phone 另用 curl GET 探一次 MCP（仅提示，不影响退出码）。
- `start_phone_service.ps1` 补 UTF-8 BOM：PowerShell 5.1 把无 BOM 文件按 GBK
  解码，中文注释里的字节会被误读成智能引号，导致整个脚本解析失败。
- 验证：离线注入假 `docker` / `python3` / `ss` / `curl`，跑通备份 5 条路径与
  启动 7 条路径；两个 ps1 用 PowerShell Parser 解析通过。

## 2026-10-21 · v1.8.0 排障从手打 SSH 变成 MCP 工具

- 新增 `deploy/ops_mcp/server.py`：零第三方依赖的 stdio MCP，走 Windows
  OpenSSH + `~/.ssh/ecs_dafeiyu`，不再每次排障手打一长串 `ssh ... docker ...`。
- 只读工具：`health`（容器 / NapCat 登录 / AstrBot WS / 端口 / 磁盘内存）、
  `logs`、`qr`、`plugins`、`cron_jobs`、`webui_info`（不返回 token）。
- 受控写操作：`restart` / `heal_ws` / `compose_up`，必须传字面确认串
  （`RESTART` / `HEAL` / `UP`）；所有调用写 `~/.dafeiyu-admin/audit.jsonl`。
- `logs` 对 `txz.qq.com` 一次性登录 URL 与 `token=` 脱敏；`qr` 把二维码落到
  `~/.dafeiyu-admin/qr.png` 并内联返回。
- 配套：`register.ps1` 注册到 Claude Code user scope；`README.md` 说明工具、
  安全边界、自检与卸载；`dafeiyu-ops` skill 改为 MCP 优先。
- 仓库不写真实主机：用 `DAFEIYU_SSH_HOST` 环境变量或 `~/.dafeiyu-admin/host`
  提供地址，`register.ps1` 以 `--env` 注入；公开仓库里只有占位符。
- 验收：`--selftest` 跑通 `health` / `plugins` / `cron_jobs` / `webui_info`；
  `claude mcp list` 显示 `dafeiyu-admin ... Connected`；PhoneMCP 的 `phone`
  SSE 也注册成功（18 工具）。
- 不造：没有做任意远程 shell；没有把 WebUI token 写进工具输出。

## 2026-10-21 · v1.7.0 她知道自己有哪些定时任务了

- 现象：01:14 她查 `future_task list` 得到“No cron jobs found”，于是说自己
  没有定时任务；但数据库里明明有叫起床、催睡觉、晚间逛 B 站三条。
- 根因：`future_task` 的 list 只列“当前会话 + 当前发送者创建”的任务。三条
  后台任务由 API/面板创建，`payload` 里没有 `sender_id`，被过滤器隐藏；
  而且她平时根本看不到这份清单，只能被动等用户问。
- 修复（治本，不是塞一条记忆）：
  - 新插件 `astrbot_plugin_schedule_awareness`：每轮 LLM 请求从
    `cron_jobs` 只读表读取当前会话名下的启用任务，实时注入系统提示词；
    支持 cron / 一次性、UTC→本地时间、按会话隔离，旧块整段替换防止重复。
  - 给三条后台任务的 `payload` 补上 `sender_id=<主人QQ>`，让
    `future_task` 的 list/edit/delete 能看到它们。
  - 人格新增规则：日程清单里的任务真实存在，不要说自己没有定时任务；
    改时间/加任务/取消要用 `future_task`，工具成功才算数。
- 验收：`tests/test_schedule_awareness.py` 覆盖 cron/一次性、会话隔离、
  UTC→本地时间；真实库回放输出四条任务，朋友会话输出空。
- 不做：没有往长期记忆里写“她有定时任务”这种会过期的笔记。

## 2026-10-21 · v1.6.0 让大肥鱼听见模拟器的声音

- 新增 PhoneMCP 工具 `listen_audio(seconds=15)`：录 Windows 默认扬声器的
  loopback（模拟器里正在播放的 B 站原声），转写成文字后返回。PhoneMCP 工具
  从 17 个增至 18 个。
- 云端新增 `deploy/phone_mcp/asr_relay.py`，只监听 `127.0.0.1:8012`；Windows
  通过 SSH `-L 8012:127.0.0.1:8012` 访问，DashScope key 只在云端读取，不复制
  到 Windows。
- `start_reverse_tunnel.ps1` 在 8009 隧道上增加 8012 本地转发；
  `start_phone_service.ps1` 会检查并拉起云端 relay、检测缺失转发时重启隧道。
- 人格新增规则：需要听视频原声时先点播放，再调用 `listen_audio`；返回
  `silent`/空就如实说没听到，不补造台词。
- 验收：Windows SAPI 中文语音 → loopback 录音 → SSH 转发 → 云端
  qwen3-asr-flash，返回“大肥鱼，你现在能听见我说话了吗？”；静音时 `peak`
  接近 0 并返回 `silent: true`。
- 依赖：PhoneMCP venv 新增 `soundcard`、`numpy`。

## 2026-10-21 · v1.5.2 中文标点归一（顿号当逗号）

- 现象：她偶尔把顿号当逗号用，例如“视频本身我这边没声音、也只看得到画面”；
  最近 52 条回复里有 13 条出现长分句顿号，另有少量「」引号。
- 根因：DeepSeek 原始输出就是这样，不是插件或 TTS 改坏的（日志里 `on_llm_response`
  之前已是原文）。
- 修复：face_convert v1.2.1 新增 `_normalize_punctuation`，在草稿箱和结果关口
  统一处理：
  - 顿号后直接跟“也 / 就 / 但 / 所以 / 或者”等分句连接词 → 逗号；
  - 「」→ “”；
  - 并列短词和数据列表（“2.7 万播放、85 条弹幕”）保持顿号，代码块原样保留。
- 人格同步加一行标点规则，从源头约束模型。
- 回归：`tests/test_face_rules.py` 新增 12 条标点用例；最近 52 条真实回复回放，
  5 条被修正、0 条误伤。

## 2026-10-20 · v1.5.1 截图必须发图 + sshd keepalive

- 人格新增硬规则：用户明确要求截图/看屏幕时，`get_screenshot` 返回图片后
  必须立刻调用 `send_message_to_user` 发图；只有收到 `Message sent` 才能
  说“图发了”，只回文字不算完成。
- 云端 sshd 增加 `ClientAliveInterval 30` / `ClientAliveCountMax 3`，
  死隧道约 90 秒回收，避免半开连接长期占着 8009/8010；脚本见
  `deploy/incident_20261020/set_ssh_keepalive.sh`。

## 2026-10-20 · v1.5.0 Browser Use 接入 + 旧测试记录隔离

- **Browser Use 0.13.11**：新增只读 BrowserMCP（SSE 8010）+ 云端代理 +
  AstrBot `browser-use` 条目；独立 Chrome、域名白名单、任务串行。
  修复 `deepseek-flash` 思考模式拒绝 `tool_choice`、扩展下载拖垮启动超时、
  Windows 控制台 GBK 乱码等坑。
- **face_convert**：抽出 `_scrub_meta_sentences`，并在 `convert_faces`
  （`on_decorating_result` 结果关口）对 Plain 文本再擦一遍，覆盖工具循环
  最终回复；代码块原样保留，不碰工具调用/结构化数据。
- **事故隔离**：把 3 个会话里的「星绘 / 必须输出 XML / 系统自检」注入测试
  三连从会话、LivingMemory 文档/图条目/节点/边/FTS/来源中定点清除；
  正常长期记忆保留，三个库关键词归零。
- **PhoneMCP**：反向隧道进程匹配按 `-Port` 区分，手机 8009 与浏览器 8010
  可同时运行。

## 2026-10-20 · v1.4.8 叫起床改到 8:00

- AstrBot 未来任务「大肥鱼叫起床」的 cron 从 `0 7 * * *` 改为
  `0 8 * * *`（`Asia/Shanghai`），提示词里的“早上 7 点”同步改为“早上 8 点”
- `next_run_time` 已核验为 2026-10-21 00:00 UTC（北京时间 08:00）；
  其余任务不变：23:30 催睡觉、20:30 逛 B 站

## 2026-10-20 · v1.4.7 未来任务：每天 20:30 自己逛 B 站

- AstrBot 新增 `active_agent` 未来任务 **大肥鱼晚间逛B站**：
  `30 20 * * *` / `Asia/Shanghai` / 私聊 `qq:FriendMessage:<主人QQ>`
- 提示词要求：结合近期聊天和长期记忆换着主题挑 → 手机 B 站搜前三条 → 挑一条
  看标题/UP/简介/页面数据 → 只按实际看到的内容汇报 → 能拿链接就拿 → 发完用
  `memorize_long_term_memory` 记活动摘要，主人评价等回复后再补
- 已验证 `next_run_time` = 2026-10-20 12:30 UTC（北京时间 20:30）；
  依赖电脑、雷电、PhoneMCP、SSH 隧道和云端 AstrBot 同时在线
- 分享链接缺口：下一步从当前视频页 Intent 的 `aid/bvid` 生成
  `bilibili.com/video/...`，不再依赖剪贴板

## 2026-10-20 · v1.4.6 手机逛 B 站：中文输入、坐标点击、开机自恢复

- B 站 `tv.danmaku.bili` v9.15.0 首启引导已处理（女 / 18-24 / 动漫+知识科普），
  当前停在首页；搜索、前三结果标题/UP 主、分享面板均已人工走通
- Android 14 上 PhoneMCP 自带的 ClipHelper `IClipboard` 旧接口报
  `NoSuchMethodException`，中文输入改走 **ADBKeyboard** IME 广播；新增
  `type_text` 的 ADBKeyboard 分支和 `tap(x,y)` 坐标点击工具，工具总数 16 → 17
- `launch_app` 增加 `B站` / `哔哩哔哩` / `Bilibili` 别名；完整源码补丁
  `deploy/phone_mcp/patches/phone_mcp_local_20261020.patch`
- 新增 `start_phone_service.ps1` / `stop_phone_service.ps1` /
  `phone_service_status.ps1` / `install_phone_autostart.ps1`：幂等启动模拟器、
  PhoneMCP、SSH 隧道和云端代理；无管理员权限时自动退回启动文件夹
- `-RestartBot` 会重启云端 AstrBot 并跑 `heal_ws.py`，解决 PhoneMCP 重启后
  AstrBot 的 MCP SSE 长连接仍是旧会话的问题；隧道脚本保留 3 秒重连循环
- 人格新增【用虚拟手机逛 App】：截图优先、元素树失败时坐标点击、只讲看清的
  内容；活动后按主人反馈用 `memorize_long_term_memory` 记简短摘要。
  LivingMemory `enable_memorize_tool` 已于 2026-10-19 开启（本次核对仍为 true）
- QQ 私聊实测通过（2026-10-20 14:23）：她自己搜“深蓝航天 可回收火箭”，
  前三条结果、选中条的标题/UP 主/播放数据与截图逐项一致；复制链接后读不到
  Android 14 剪贴板，她如实说“链接没拿到”，没有编造

## 2026-10-20 · v1.4.5 快速登录接线：NapCat 被踢后少扫码

- Docker 入口脚本读的是 `ACCOUNT`（`qq --no-sandbox -q $ACCOUNT`），
  原模板写的 `NAPCAT_ACCOUNT` 是无效变量；云端 compose 已改正，并加
  `NAPCAT_QUICK_ACCOUNT`，被踢后 Worker 重启会自动尝试快速登录
- 实测：容器重建后首次仍需扫码（QQ 提示“未找到历史登录记录”，设备指纹
  随容器变化）；扫码后 OneBot11 WS 正常回连 AstrBot。以后改配置优先
  `docker restart` 或 WebUI，别频繁 `docker compose up -d` 重建
- `deploy/README.md` 补快速登录变量名与“重建会丢记录”的坑

## 2026-10-20 · v1.4.4 手机控制接通：PhoneMCP → 云端 AstrBot

- 本地 Windows 雷电 14 模拟器（`720×1280 / 320 dpi / 30 fps`，默认 6 vCPU / 6 GB）
  通过 **PhoneMCP + ADB + MCP** 接入云端 AstrBot，设备 `emulator-5554`
- 官方 `phone-mcp-windows-amd64.exe` 在中文控制台启动横幅 emoji 处崩溃
  （`UnicodeEncodeError: 'gbk' codec can't encode character '✅'`，v0.5.0/v0.3.4
  均复现），改为官方源码运行；`deploy/phone_mcp/patch_phone_mcp_main.py` 在
  `main.py` 入口强制 stdout/stderr 为 UTF-8
- 网络走 **SSH 反向隧道**：本地 `127.0.0.1:8009` → 云端 `127.0.0.1:8009`；
  Windows 脚本带 `ServerAliveInterval` 和断线 3 秒重连。云端
  `phone_mcp_proxy.py` 监听 Docker 网关 `172.18.0.1:8009` 再转发到回环，
  解决“容器里的 127.0.0.1 指容器自身”的问题
- AstrBot `data/mcp_server.json` 配置 SSE 端点 `/Phone`（fastmcp 4.x 实际路径，
  不是 PhoneMCP 打印的 `/Phone/sse`），重启后 16 个工具全部注册
- QQ 实测通过：`list_devices` → `get_current_app` → `get_screenshot` →
  `launch_app(com.android.settings)` → `get_ui_elements`；她准确说出
  “网络和互联网 / 已连接的设备”及副标题，和截图逐字一致
- 新增 `deploy/phone_mcp/`：接线说明、云端代理、源码 UTF-8 补丁、
  PhoneMCP/反向隧道启动脚本、`mcp_server.json` 示例
- 未来任务（定时分享）仍未创建，先完成手动控制验收

## 2026-10-19 · v1.4.3 联网搜索打通：正常聊天 + 主动消息都能查

- AstrBot 网页搜索启用：提供商 `anysearch`，API Key 留空使用匿名每日额度，
  同时打开来源引用（`web_search_link=true`）；原配置备份
  `data/cmd_config.before_websearch_20261019_2315.json`
- 正常聊天实测：会话记录出现 3 次 `web_search_anysearch` 调用，返回官方
  `github.com/AstrBotDevs/AstrBot/releases` 链接，回复只列可确认的 v4.29.0 变更
- 主动消息插件 v1.2.6 补丁：主动消息原本直调 `provider.text_chat()`，不挂工具、
  也没有工具循环。新增 `func_tool` 挂载与最多 3 轮的“执行工具 → 带结果重问”循环
  （补丁文件在 `deploy/patches/proactive_chat/`，升级插件后需重打）
- 主动消息实测：日志出现 2 次 `工具 web_search_anysearch 执行完成`（结果长度
  1105 / 1166 字），重问后发出带新鲜话题的消息
- 主动提示词末尾增加“想聊新鲜话题时可先联网搜索”的软引导，不强制每条都搜；
  最大未回复次数恢复为 `2`，免打扰恢复 `23-8`，测试产生的未回复计数已清零
- `docs/部署指南.md` 新增网页搜索与主动消息联网两节；README 能力清单同步

## 2026-10-19 · v1.4.2 人格 v2.1：允许黏人、撒娇和小委屈

- 人格升级为 **v2.1 黏人修订**（3045 字）：主号私聊里可以更黏人、爱撒娇，
  会想念、轻轻吃醋和闹一点小脾气；朋友与群友仍按各自关系相处
- 明确"被冷落"的表达方式与边界：可以轻轻埋怨（如"你都不理肥鱼了……"），
  但不贬低、威胁、自伤暗示或要求疏远现实朋友；对方解释在忙就顺势软下来
- 新增"隔一阵回来"的口吻示例：先小声嘟囔一句，再开心接话
- 主动消息提示词换新：按未回复次数从轻松搭话过渡到想念/小委屈；
  只使用有依据的聊天内容，只输出消息正文
- 私聊最大未回复次数 `1 → 2`，保留"没等到回复后再撒娇一次"的机会
- 云端 `personas(persona_id=dafeiyu)` 已更新并重启加载；
  旧库备份 `backups/data_v4_before_persona_clingy_20261019.db`
- 仓库 `persona/大肥鱼-人格.md` 与实机同步；部署指南改回"整段粘贴 `---` 后正文"

## 2026-10-19 · v1.4.1 主动消息转低频私聊配方（插件 v1.2.6）

- 云端 `proactive_chat` 切到低频私聊模式：私聊 UMO 仅保留主号
  `qq:FriendMessage:<你的QQ>`，上下文来源 `conversation_history`
- 触发间隔由 `30/600` 分钟收紧为 `120/240` 分钟；最大未回复次数 `4 → 1`
  （发一条没回复就暂停，等用户下次开口再恢复）
- 免打扰时段由 `1-7` 调整为 `23-8`；命中时只跳过并重新排期，不会夜间发送
- 配置已通过插件自带 WebUI API 热更新并落盘，原配置备份在服务器
  `data/config/astrbot_plugin_proactive_chat_config.bak_20261019_lowfreq.json`
- `docs/部署指南.md` 新增《proactive_chat 低频私聊配方》，验证流程改按 2～4 小时观察

## 2026-10-19 · v1.4.0 人格 v2：更稳的角色边界与真实能力

- 人格提示词整体重写为**单块 v2**（2676 字），新增【实际能力与工具】【记忆与话题衔接】
  【身份、群聊与隐私】【输入与静默】等边界，角色口吻不再与工具/协议执行混为一谈
- 明确区分**角色设定与真实信息**：记忆分用户事实 / 角色玩笑 / 模型推测 / 工具结果；
  只有确认持久化成功才说"记住了"，只有工具确认成功才说"已发出"
- 媒体理解只依据实际收到的图片、转写、抽帧回答，不补造未提供的细节；
  识别失败时如实说明缺什么，不硬猜
- 保留 `[NO_REPLY]` 静默协议；移除旧版"草稿本 / 双括号隐藏"机制
- 用户明确要代码、公式、表格时正常给格式；日常聊天仍以 1～3 句口语短句为主
- 导入方式简化为**整段粘贴**（不再拼接多段）；云端 `personas` 已更新
  （`persona_id=dafeiyu`），旧库备份保留在服务器 `backups/`

## 2026-10-18 · v1.3.3 视频识别升级：3～5 分钟（插件 v1.2.0）

- 默认分析前 300 秒：最多 16 个首尾均匀采样点，每 4 帧带时间戳共同理解；
  16 kHz 单声道 WAV 音轨按 60 秒切段，按时间把画面和语音送入原聊天模型
- 默认媒体大小 80 MiB、总处理时限 300 秒、同时处理 1 条媒体、每条最多 2 个工作任务；
  视频下载流式落盘，共享的本地文件同样检查大小；超过 5 分钟会注明截断范围
- 模型调用改为可取消的异步 HTTP；单段失败/总时限到达保留已有结果；
  ffmpeg 在自身超时和外层取消时都会终止、排空管道并回收，随后清理临时目录
- 排队等待设上限；部分识别结果如实注入上下文，相关失败说明不再被嘴硬橡皮擦删除
- 新增本地 HTTP 与真实 ffmpeg 回归测试，覆盖 3/5 分钟末尾、静音短片、截断、
  单段失败、大小限制、超时取消和临时文件清理；模型与 QQ 实际效果待部署验证

## 2026-10-18 · v1.3.2 备份自带 WS 自愈

- `backup.sh` 恢复容器后自动跑 `heal_ws.py`——AstrBot 重启后 NapCat 的 WebSocket
  **不会自愈**（今天实测复现），每晚备份重启后靠这步把连接拉回来
- `deploy/heal_ws.py` 随仓库提供：容器版"关一下再开 websocketClients"，
  不重启 QQ、不扫码；平时发消息没反应时也可手动跑一次

## 2026-10-18 · v1.3.1 审阅修复：橡皮擦不误删 + 部署可复现

外部代码审阅发现的六类问题，逐条修复：

- **嘴硬橡皮擦误删（最要命）**：停用符集补上中文逗号「，」，关键词后不再跨句吞字；
  含「重发 / 再说一遍」等请求词的整条回复**永不误删**；`config.json` 可整体关闭。
  回归用例钉死："我看不清，你能重发一张吗？" 必须原样保留
- **视频失败文案**：不再无条件"你看得很清楚"；解析失败/超时如实降级为"（你没看清）"
- **file:// 路径**：统一 `file_uri_to_path()`（Windows / Linux / http 三态）——
  Linux 下 `file:///tmp/x` 不再被截成相对路径
- **媒体资源硬化**：流式下载限 20MB；ffmpeg 超时强制杀进程并回收；语音临时文件用完即删；
  视频外层超时捕获降级；媒体并发上限 2（参数均可配）
- **表情冷却**：按会话隔离 + 10 分钟过期，不再出现"A 群用过的脸把 B 群也冷却了"
- **部署套件补齐**：`deploy/patches/` 随仓库提供（附来源 / AGPL-3.0 说明）；镜像钉版
  （AstrBot v4.29.0 / NapCat 镜像 v4.18.37）；`backup.sh` 改为"短暂停服 → 临时包 → 成功改名 →
  失败可见"，并把 compose / Dockerfile / patches 纳入备份；面板与 NapCat WebUI 默认绑 127.0.0.1
  （SSH 隧道访问）
- 新增 `tests/test_face_rules.py` 回归测试（10 项全过）

## 2026-10-17 · v1.3.0 云上安家（Docker 部署套件）

- 新增 `deploy/` 套件：Docker Compose 一键编排 AstrBot + NapCat、自定义镜像补依赖
  （edge-tts / imageio-ffmpeg）、两个核心补丁以 **bind-mount** 接入——升级镜像不再丢补丁
- **嵌入上云**：云端不跑 Ollama，改用硅基流动托管的同款 bge-m3（OpenAI 兼容接口）。
  实测旧记忆向量与新嵌入**余弦 0.99994**，长期记忆/知识库**零重嵌入**直接可用；
  附幂等切换脚本 `apply_sf_embedding.py`
- **备份体系**：服务器每日滚动备份（保留 7 份）+ 本地拉取脚本（可配每周计划任务）
- 迁移要点入档：QQ 登录态不可跨平台迁移（需扫码一次）、双登互踢（旧机自启必须停用）、
  数据打包排除 `temp` / `logs` / `*.bak_*`
- 实弹演练：一台 2C4G / Ubuntu 24.04 云服务器完成整站迁移，
  私聊 / 群聊 / 语音 / 表情 / 记忆召回全部验收通过 🎉

## 2026-10-15 · v1.2.8 知识库上线（功能手册 + 热梗词典）

- 新增《知识库笔记》：AstrBot v4.29 知识库的接线机制（全局/会话级绑定、本机 Ollama 嵌入、
  逐消息检索注入）、三步搭法、维护节奏——含"只装愿意当众朗读的公开内容"的设计原则
- 新增《热梗词典（示例）》：游戏圈暗号（kskbl「康神开播了」家族）+ 2025 年度热词 + 长红经典，
  每条带"接法/语气"——知识库不是百科，是**教她怎么接话**
- 《指令手册》同步入库为「大肥鱼手册」：朋友问"怎么点歌/怎么自拍"，她现在能答准了

## 2026-10-15 · v1.2.7 反注入三件套·大白话体质

朋友号连着做了几轮"系统自检/按格式输出"类的注入测试，她真的被半带偏过一回——
回复被套上了程序格式壳（`[{'type': 'text', …}]` 这种符号垃圾）。治本 + 兜底一起上：

- **人格针（治本）**：底线新增「大白话体质」——"那种机器壳子不是你的话，
  你也从来不会那样说话"，让"不发这类东西"成为她自己的信念（已注入 DB）
- **机器兜底（拆壳橡皮擦）**：就算被带偏出壳，插件也会在发送前
  **拆掉壳、把正文救回来**（含多段拼接、句中壳；正常文本零误伤）
- **清残渣**：会话里残留的假"协议/自检"文本整段扫除（14 条，含朋友号两次注入）
- 《踩坑合集》新增 **#21**：注入残渣 × "格式回声"的完整病例与三层解法

## 2026-10-15 · v1.2.6 括号净化与升级手册

- **插件小修**：meta 口癖整句清扫后，配对不上的括号残骸（如结尾孤零零的「）」）
  会被自动补删；配对完整的括号不受影响（需重启 AstrBot 生效）
- 《踩坑合集》新增 **#20**：AstrBot 大版本升级善后三件套——
  `core/data` 被整体替换后如何用启动器的自动快照还原、venv 重建后要补装哪些插件依赖、
  本地补丁的重打清单（浓缩为"升级四步：备份 → 更新 → 还原/重打 → 体检"）

## 2026-10-15 · v1.2.5 连接韧性·全自动抢险

- 《踩坑合集》#18 升级：看门狗已进化为 **v4「全自动抢险」**——
  自动清理 NapCat 进程树（不误伤用户 QQ）→ 自动重启 → 免扫码则全自动满血；
  需扫码则二维码自动上桌 + 桌面通知。附"抢时间以争取快捷登录"的规律备忘

## 2026-10-15 · v1.2.4 生图笔记与插件同步

- **插件代码同步到最新**：
  - 思维链防漏滤镜（EmotionAI 的 `<thought>` 块出门前摘除，文字与语音双通道都干净）
  - 语音开关指令（`/语音开` `/语音关` `/语音状态`，会话级持久化）
- 新增《生图玩法 · 配置笔记》：两条链路分工 / 自拍三件套 / `base_url` 全路径规则 / 调参经验 / 素材授权
- 《踩坑合集》新增 **#19**：第三方生图服务没有 `/images/edits` 的解法 + 参考图路径校验规则

## 2026-10-15 · v1.2.3 指令手册

- 新增《指令手册》速查表：语音开关 / 画图·自拍·视频 / 点歌 / 表情包 / 互动 / 定时服务 / 内置指令，一页全收录
- 新增插件指令：`/语音开` `/语音关` `/语音状态`（会话级语音条开关，持久化）

## 2026-10-15 · v1.2.2 定时服务配方

- README《推荐搭配》：把「未来任务」贴士升级为**照抄即用的定时人设消息配方**——
  每晚 23:30「催睡觉」+ 每天 07:00「叫起床」，任务说明原文全给出

## 2026-10-15 · v1.2.1 连接韧性

深夜抢险沉淀下来的一课：

- 《踩坑合集》新增 **#18**：NapCat 内部"半重启"导致 WebUI 认证损坏（`Not Login`）——
  判据、"安全清理进程树"步骤、整机重启 + 扫码流程全部记录在案
- 看门狗 v3：巡检提速到 **90 秒**；识别出"Not Login 坏状态"时会明确报警
  "API 修不动、需要整机重启"，不再默默重试

> README 无变化——本次为运维知识沉淀，不影响使用方式。

## 2026-10-15 · v1.2 生态篇

从"会聊天的鱼"到"能一起玩的朋友"。

### 📝 文档

- README 新增《推荐搭配》：六个与本项目**零冲突**、实战验证过的插件玩法
  （链接解析 / 点歌 / 戳一戳 / 表情包偷取与生成 / 生图），外加内置「未来任务」的定时人设消息小贴士
- 《踩坑合集》新增 **#17**（插件市场装不上 → `proxy` 前缀加速）；
  补充 **#5**（重启后的连接"空白期"与看门狗加固思路）

> 配套技巧均已在真机验证：六个插件安装、生图链路、群聊全链路——全程畅通。

## 2026-10-14 · v1.1 首版上线

- 核心插件 `astrbot_plugin_face_convert`：表情转换 + 入站翻译（表情/语音/图片/视频）+ 草稿箱 + 三道橡皮擦
- 人格《大肥鱼》、课程记忆模板（"让她自己悟"）
- 《部署指南》《踩坑合集》（1~13 坑）
- 头像素材 12 张（含授权署名）、声音样本与复刻链路说明

## 2026-10-14 · v1.1 当日进化（群聊 + 记忆隔离）

从"会聊天的鱼"到"住进群里的鱼"。

### ✨ 新功能

- **群聊支持**：@她 / 引用她 / 以「大肥鱼」开头喊她都能唤醒；没人叫她时安静旁观
- **身份标记（插件 v1.1.0）**——让她分得清"谁在说话"：
  - 群聊 → 消息带上 `[昵称(QQ号)]`，管理员标「主人」
  - 私聊访客 → `[主人的朋友 昵称(QQ号)]`，她会热情又有分寸（不搬私事）
  - 只喊名字没内容 → 补一个"（喊了你一声）"的回应由头
  - 标记只进她的上下文，**对方看不到一个字**
- **记忆按会话隔离**：livingmemory 切 `session` 作用域——每个私聊、每个群各一册记忆，不同账号互不串账
- 人格新增《群聊守则》《朋友来访》《你的话都是你的》三块

### 🔧 修复

- **语音不再念出 `[旺柴]`**：TTS 合成前过滤表情标记；纯标点（"……"）也不再合成语音
- **"关心变念经"循环**：记忆反思写错的"事实"被当真、被反复追问——根因与解法见《踩坑合集》#16

### 📝 文档

- 新增《导入指南》（人格 / 课程记忆 / 音色，手把手）
- 《踩坑合集》新增 #14（语音念出表情标记）、#15（qwen-audio 的两个源码补丁）、#16（记忆反思会写错事实）
